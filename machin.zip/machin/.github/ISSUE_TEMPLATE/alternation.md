---
name: Alternation
about: Something you find inconvinient and needs to be alternated.
title: "[ALTER]"
labels: allter
assignees: ''

---

**Where to alter**

**Why to alter**
illy designed?
bad naming / strange acronyms?
obscured function description?
lack of inline comments?
Unecessary document?

**How to alter**
Your suggested altenation, preferably a detailed example.
