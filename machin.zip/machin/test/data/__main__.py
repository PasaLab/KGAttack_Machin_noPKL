from .all import generate_all

if __name__ == "__main__":
    generate_all()
