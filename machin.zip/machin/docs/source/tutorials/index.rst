Tutorials
==================
.. toctree::
    :maxdepth: 1

    Your first program <your_first_program.rst>
    As fast as lightning <as_fast_as_lightning.rst>
    Data flow in Machin <data_flow_in_machin.rst>
    Parallel, distributed <parallel_distributed.rst>
    Unleash distributed power <unleash_distributed_power.rst>
    Recurrent networks <recurrent_networks.rst>
