API
==================
.. toctree::

   machin.env.rst
   machin.auto.rst
   machin.frame.rst
   machin.model.rst
   machin.utils.rst
   machin.parallel.rst